﻿'EquipmentDB
'Form that lets the user select a payment method.
'Mason Ward
'27/11/2019

Imports HMCBOC
Imports System.Data.SqlClient
Public Class Payment
    Dim _amount As Decimal
    Dim _method As String
    Dim _paymentDate As Date
    Dim _hireID As Integer
    Dim success As Boolean
    Dim sqlMessage As String = "Could not read or write to the database." & vbCrLf & "No changes have been made"
    Dim exMessage As String = "An unexpected error occured." & "No changes have been made."
    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        PaymentDate = Date.Today
        Try
            If Validator.HasSelection(cboMethod) Then
                _method = cboMethod.SelectedItem.ToString
                Dim payment As New HMCBOC.Payment(_amount, _paymentDate, _method, _hireID)
                success = HMCBOC.Payment.EnterPayment(payment)
                If success = True Then
                    MessageBox.Show("Success")
                    Me.Close()
                Else
                    MessageBox.Show("Error")
                End If
            End If
        Catch ex As SqlException
            MessageBox.Show(sqlMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Catch ex As Exception
            MessageBox.Show(exMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Public Property PaymentDate As Date
        Get
            Return _paymentDate
        End Get
        Set(value As Date)
            _paymentDate = value
        End Set
    End Property

    Public Property HireID As Integer
        Get
            Return _hireID
        End Get
        Set(value As Integer)
            _hireID = value
        End Set
    End Property

    Public Property Amount As Decimal
        Get
            Return _amount
        End Get
        Set(value As Decimal)
            _amount = value
        End Set
    End Property

    Private Sub BtnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        Me.Close()
    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub CboMethod_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboMethod.SelectedIndexChanged

    End Sub

    Private Sub Payment_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class