﻿'Mason Ward
'26/09/2019
'Has functions for validating input data

Module Validator
        'Validates that a text box is not empty
        Function IsPresent(text As TextBox) As Boolean
            If text.Text = "" Then
                Return False
            Else
                Return True
            End If
        End Function

        Function IsPresentLable(text As Label) As Boolean
            If text.Text = "" Then
                Return False
            Else
                Return True
            End If
        End Function

        'Validates that the numeric value in a text box is within a certain range
        Function IsWithinRange(text As TextBox, low As Integer, high As Integer) As Boolean
            Try
                Dim value As Integer = CInt(text.Text)
                If value < low OrElse value > high Then
                    Return False
                Else
                    Return True
                End If
            Catch ex As OverflowException
            Catch ex As FormatException
            End Try
        End Function

        'validates that a combo box has an item selected
        Function HasSelection(box As ComboBox) As Boolean
            If box.SelectedIndex = -1 Then
                Return False
            Else
                Return True
            End If
        End Function

        'validates that the value in a textbox contains only letters and white space
        Function OnlyAplha(textBox As TextBox) As Boolean
            Dim text As String = textBox.Text
            Dim returnValue As Boolean = True
            For Each c As Char In text
                If Char.IsLetter(c) Or Char.IsWhiteSpace(c) Then
                Else
                    returnValue = False
                    Exit For
                End If
            Next
            Return returnValue
        End Function
    End Module

