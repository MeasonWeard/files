﻿'EquipmentDB
'Main menu of the application.
'Mason Ward
'27/11/2019

Imports HMCBOC
Imports System.Data.SqlClient
Public Class FormMain
    Dim sqlMessage As String = "Could not read or write to the database." & vbCrLf & "No changes have been made"
    Dim exMessage As String = "An unexpected error occured." & "No changes have been made."
    Dim _patients As New DataTable
    Dim _hires As New DataTable
    Dim _payments As New DataTable
    Dim _equipment As New DataTable
    Dim _equiptType As New DataTable
    Dim dataSet As New DataSet
    Dim patientHire As DataRelation
    Dim hireEquipment As DataRelation
    Dim equipmentEquipType As DataRelation
    Dim hirePayment As DataRelation
    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles mnuExit.Click
        Me.Close()
    End Sub

    Private Sub mnuPatients_Click(sender As Object, e As EventArgs) Handles mnuPatients.Click
        Dim frmPatients As New FormPatients
        frmPatients.MdiParent = Me
        frmPatients.Show()
    End Sub
    Private Sub mnuHire_Click(sender As Object, e As EventArgs) Handles mnuHire.Click
        Dim frmHire As New FormHire
        frmHire.MdiParent = Me
        frmHire.Show()
    End Sub
    Private Sub FormMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try
            EquipmentType.Update()
            Equipment.Update()
        Catch ex As SqlException
            MessageBox.Show(sqlMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Catch ex As Exception
            MessageBox.Show(exMessage & vbCrLf & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Public Property Patients As DataTable
        Get
            Return _patients
        End Get
        Set(value As DataTable)
            _patients = value
        End Set
    End Property

    Public Property Hires As DataTable
        Get
            Return _hires
        End Get
        Set(value As DataTable)
            _hires = value
        End Set
    End Property

    Public Property Payments As DataTable
        Get
            Return _payments
        End Get
        Set(value As DataTable)
            _payments = value
        End Set
    End Property

    Public Property EquipmentTypes As DataTable
        Get
            Return _equiptType
        End Get
        Set(value As DataTable)
            _equiptType = value
        End Set
    End Property

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub
End Class