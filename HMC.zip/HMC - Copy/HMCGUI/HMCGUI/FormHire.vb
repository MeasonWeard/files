﻿'EquipmentDB
'Form for making new hires.
'Mason Ward
'27/11/2019

Imports HMCBOC
Imports System.Data.SqlClient
Public Class FormHire
    Dim dtEquipment As DataTable
    Dim typeList As List(Of String)
    Dim patientList As List(Of String)
    Dim bs As New BindingSource
    Dim costPerDay
    Dim sqlMessage As String = "Could not read or write to the database." & vbCrLf & "No changes have been made"
    Dim exMessage As String = "An unexpected error occured." & "No changes have been made."
    Private Sub FormHire_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        typeList = EquipmentType.GetTypeList()
        For Each et As String In typeList
            cboEquipmentType.Items.Add(et)
        Next
        dtEquipment = Nothing
        bs.DataSource = dtEquipment
        dgvEquipment.AllowUserToAddRows = False
        dgvEquipment.DataSource = bs
        DisplayPatientInfo()
    End Sub

    Private Sub CboEquipmentType_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboEquipmentType.SelectedIndexChanged
        UpdateEquipment()
    End Sub

    Private Sub UpdateEquipment()
        Dim typeText As String = cboEquipmentType.SelectedItem.ToString
        Dim typeID As String
        Dim equipID As String
        Try
            typeID = cboEquipmentType.SelectedItem.ToString.Substring(0, 3)
            dtEquipment = Equipment.GetByType(typeID)
            bs.DataSource = dtEquipment
            dgvEquipment.DataSource = bs
            bs.ResetBindings(False)
            For i As Integer = 0 To dtEquipment.Rows.Count - 1
                equipID = dgvEquipment.Rows(i).Cells(0).Value.ToString
                If Equipment.IsAvailable(equipID) Then
                    For Each c As DataGridViewCell In dgvEquipment.Rows(i).Cells
                        c.Style.BackColor = Color.White
                    Next
                Else
                    For Each c As DataGridViewCell In dgvEquipment.Rows(i).Cells
                        c.Style.BackColor = Color.DarkGray
                    Next
                End If
            Next
            'Displays cost per day of selected equipment type
            If dtEquipment.Rows.Count > 0 Then
                costPerDay = EquipmentType.GetCostPerDay(typeID)
                lblCost.Text = FormatCurrency(costPerDay)
            Else
                lblCost.Text = FormatCurrency(0)
            End If
        Catch ex As SqlException
            MessageBox.Show(sqlMessage & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Catch ex As Exception
            MessageBox.Show(exMessage & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try

    End Sub

    Private Sub DisplayPatientInfo()
        Dim ID As Integer
        Dim pat As New Patient()
        If Validator.IsPresent(txtID) Then
            If IsNumeric(txtID.Text) Then
                If Validator.IsWithinRange(txtID, 0, 99999) Then
                    ID = CInt(txtID.Text)
                    pat = Patient.GetByID(ID)
                    If pat IsNot Nothing Then
                        lblFirstName.Text = pat.FirstName
                        lblLastName.Text = pat.LastName
                        lblStreet.Text = pat.Street
                        lblSuburb.Text = pat.Suburb
                        lblState.Text = pat.State
                        lblPostCode.Text = pat.PostCode
                        lblPhone.Text = pat.Phone
                        lblEmail.Text = pat.Email
                    Else
                        MessageBox.Show("Patient not found")
                        lblFirstName.Text = ""
                        lblLastName.Text = ""
                        lblStreet.Text = ""
                        lblSuburb.Text = ""
                        lblState.Text = ""
                        lblPostCode.Text = ""
                        lblPhone.Text = ""
                        lblEmail.Text = ""
                    End If
                End If
            Else
                MessageBox.Show("Please only numbers for patiend ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If
        Else
            txtID.Text = 0
        End If
    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        DisplayPatientInfo()
    End Sub

    Private Sub BtnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        txtID.Text = CInt(txtID.Text) - 1
        DisplayPatientInfo()
    End Sub

    Private Sub BtnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        txtID.Text = CInt(txtID.Text) + 1
        DisplayPatientInfo()
    End Sub

    Private Sub BtnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub BtnHire_Click(sender As Object, e As EventArgs) Handles btnHire.Click
        Dim pt As Point
        Dim available As Boolean
        Dim equipID As String
        Dim patID As Integer
        Dim serialNo As String
        Dim dateHired As Date
        Dim dateReturned As Date
        Dim hireCost As Decimal
        Dim success As Boolean = False
        Dim result As DialogResult
        pt = dgvEquipment.CurrentCellAddress
        Try
            If Validator.IsPresent(txtID) Then
                If IsNumeric(txtID.Text) Then
                    Try
                        Dim patient As Patient
                        patID = txtID.Text
                        patient = Patient.GetByID(patID)
                        If patient IsNot Nothing Then
                            If dgvEquipment.Rows.Count > 0 Then
                                If pt.Y.ToString <> "-1" Then
                                    equipID = Trim(dgvEquipment.Item(0, pt.Y).Value)
                                    available = Equipment.IsAvailable(equipID)
                                    If available = True Then
                                        result = MessageBox.Show("Are you sure you want to hire out " & equipID & " to the patient " & lblFirstName.Text &
                                                                 " " & lblLastName.Text & "?", "Are you sure?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                                        If result = DialogResult.Yes Then
                                            patID = CInt(txtID.Text)
                                            serialNo = equipID
                                            dateHired = Date.Today
                                            dateReturned = Nothing
                                            hireCost = 0
                                            Dim newHire As New Hire(patID, serialNo, dateHired, dateReturned, hireCost)
                                            success = Hire.EnterHire(newHire)
                                        End If
                                    Else
                                        MessageBox.Show("Selected equipment is not currenty available", "Not available",
                                                        MessageBoxButtons.OK, MessageBoxIcon.Information)
                                    End If
                                Else
                                    MessageBox.Show("No equipment selected.", "No selection", MessageBoxButtons.OK, MessageBoxIcon.Information)
                                End If
                            End If
                        Else
                            MessageBox.Show("Patient not found.", "", MessageBoxButtons.OK, MessageBoxIcon.Information)
                        End If
                    Catch ex As Exception
                        MessageBox.Show(ex.Message)
                    End Try
                Else
                    MessageBox.Show("Please only numbers for patiend ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If
            End If
            If success = True Then
                MessageBox.Show("Equipment has been hired.", "Hired", MessageBoxButtons.OK, MessageBoxIcon.Information)
                UpdateEquipment()
            End If
        Catch ex As SqlException
            MessageBox.Show(sqlMessage & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Catch ex As Exception
            MessageBox.Show(exMessage & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub
End Class