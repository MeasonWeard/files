﻿'EquipmentDB
'Form for seeing a patient's related hires, returning them and making payments.
'Mason Ward
'27/11/2019

Imports HMCBOC
Imports System.Data.SqlClient
Public Class FormPatients
    Dim patients As DataTable
    Dim bs As New BindingSource
    Dim HireList As New List(Of Hire)
    Dim sqlMessage As String = "Could not read or write to the database." & vbCrLf & "No changes have been made"
    Dim exMessage As String = "An unexpected error occured." & "No changes have been made."
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub FormPatients_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        patients = FormMain.Patients
        bs.DataSource = HireList
        dgvHires.AllowUserToAddRows = False
        dgvHires.DataSource = bs
        DisplayPatientInfo()
    End Sub

    Private Sub BtnSearch_Click(sender As Object, e As EventArgs) Handles btnSearch.Click
        DisplayPatientInfo()
    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        txtID.Text = CInt(txtID.Text) - 1
        DisplayPatientInfo()
    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        txtID.Text = CInt(txtID.Text) + 1
        DisplayPatientInfo()
    End Sub

    Private Sub DisplayPatientInfo()
        Dim ID As Integer
        Dim pat As New Patient()
        Try
            If Validator.IsPresent(txtID) Then
                If IsNumeric(txtID.Text) Then
                    If Validator.IsWithinRange(txtID, 0, 99999) Then
                        ID = CInt(txtID.Text)

                        pat = Patient.GetByID(ID)
                        If pat IsNot Nothing Then
                            lblFirstName.Text = pat.FirstName
                            lblLastName.Text = pat.LastName
                            lblStreet.Text = pat.Street
                            lblSuburb.Text = pat.Suburb
                            lblState.Text = pat.State
                            lblPostCode.Text = pat.PostCode
                            lblPhone.Text = pat.Phone
                            lblEmail.Text = pat.Email
                            Dim newHireList As New List(Of Hire)
                            newHireList = Hire.GetByPatID(ID)
                            bs.DataSource = newHireList
                            bs.ResetBindings(False)
                        Else
                            MessageBox.Show("Patient not found")
                            lblFirstName.Text = ""
                            lblLastName.Text = ""
                            lblStreet.Text = ""
                            lblSuburb.Text = ""
                            lblState.Text = ""
                            lblPostCode.Text = ""
                            lblPhone.Text = ""
                            lblEmail.Text = ""
                        End If
                    End If
                Else
                    MessageBox.Show("Please only numbers for patiend ID", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                End If
            Else
                txtID.Text = 0
            End If
        Catch ex As SqlException
            MessageBox.Show(sqlMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Catch ex As Exception
            MessageBox.Show(exMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub btnReturn_Click(sender As Object, e As EventArgs) Handles btnReturn.Click
        Dim pt As Point
        Dim ID As Integer
        Dim returnDate As Date
        Dim success As Boolean
        Dim response As New DialogResult
        Try
            pt = dgvHires.CurrentCellAddress
            If dgvHires.Rows.Count > 0 Then
                If pt.Y.ToString = "-1" Then
                    MessageBox.Show("No hire selected", "No selection", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                Else
                    returnDate = dgvHires.Item(4, pt.Y).Value
                    If returnDate.Year = 1 Then
                        ID = dgvHires.Item(0, pt.Y).Value
                        If Hire.ReturnHire(ID) Then
                            DisplayPatientInfo()
                            response = MessageBox.Show("Make payment?", "Make payment?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                            If response = DialogResult.Yes Then
                                MakePayment()
                            End If
                        Else
                            MessageBox.Show("Nope")
                        End If
                    Else
                        MessageBox.Show("Selected hire has already been returned.", "", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
                    End If
                End If
            Else
                MessageBox.Show("No customer selected", "No selection", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            End If
        Catch ex As SqlException
            MessageBox.Show(sqlMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Catch ex As Exception
            MessageBox.Show(exMessage & vbCrLf & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub CloseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles CloseToolStripMenuItem.Click
        Me.Close()
    End Sub

    Private Sub MakePayment()
        Dim pt As Point
        Dim id As Integer
        pt = dgvHires.CurrentCellAddress
        Try
            If dgvHires.Rows.Count > 0 Then
                id = dgvHires.Item(0, pt.Y).Value
                If Hire.hasBeenPaid(id) = False Then
                    If pt.Y.ToString <> "-1" Then
                        Dim frmPayment As New Payment
                        frmPayment.HireID = id
                        frmPayment.Amount = dgvHires.Item(5, pt.Y).Value
                        frmPayment.Show()
                    End If
                Else
                    MessageBox.Show("Payment has already been made.")
                End If
            End If
        Catch ex As SqlException
            MessageBox.Show(sqlMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Catch ex As Exception
            MessageBox.Show(exMessage & vbCrLf & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub

    Private Sub BtnPayment_Click(sender As Object, e As EventArgs) Handles btnPayment.Click
        Dim pt As Point
        Dim id As Integer
        pt = dgvHires.CurrentCellAddress
        id = dgvHires.Item(0, pt.Y).Value
        Try
            If Hire.hasBeenPaid(id) = False Then
                MakePayment()
            Else
                MessageBox.Show("Equipment has not yet been returned", "Not returned.", MessageBoxButtons.OK, MessageBoxIcon.Information)
            End If
        Catch ex As SqlException
            MessageBox.Show(sqlMessage, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        Catch ex As Exception
            MessageBox.Show(exMessage & vbCrLf & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
        End Try
    End Sub
End Class