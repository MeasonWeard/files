﻿'EquipmentDB
'Has methods for reading from and updating the Payment table.
'Mason Ward
'27/11/2019

Imports System.Data.SqlClient
Public Class PaymentDB
    Shared connStr As String = My.Settings.HMCConnectionString
    Shared conn As New SqlConnection(connStr)

    ''' <summary>
    ''' Returns a datatable with all payments from the Payment table.
    ''' </summary>
    ''' <returns>
    ''' Payments from the Payment table.
    ''' </returns>
    Public Shared Function LoadPayments() As DataTable
        Dim dataAdapter As SqlDataAdapter
        Dim dataSet As New DataSet
        Dim connStr As String = My.Settings.HMCConnectionString
        Dim conn As New SqlConnection(connStr)
        Dim comBuilder As New SqlCommandBuilder
        Dim query As String = "SELECT * FROM Payment"
        Dim col(0) As DataColumn
        Try
            dataAdapter = New SqlDataAdapter(query, connStr)
            comBuilder = New SqlCommandBuilder(dataAdapter)
            dataAdapter.Fill(dataSet, "Payment")
            col(0) = dataSet.Tables("Payment").Columns("Payment")
            dataSet.Tables("Payment").PrimaryKey = col
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dataSet.Tables("Payment")
    End Function

    ''' <summary>
    ''' Inserts a new payment into the Payment table.
    ''' </summary>
    ''' <param name="amount"></param>
    ''' Dollar amount of the payment.
    ''' <param name="paymentDate"></param>
    ''' Date the payment was made.
    ''' <param name="method"></param>
    ''' Method of payment.
    ''' <param name="hireID">
    ''' ID of the related hire.
    ''' </param>
    ''' <returns>
    ''' True if successful, false if not.
    ''' </returns>
    Public Shared Function EnterPayment(amount As Decimal, paymentDate As Date, method As String, hireID As Integer) As Boolean
        Dim dataAdapter As New SqlDataAdapter
        Dim builder As SqlCommandBuilder
        Dim cmd As New SqlCommand
        Dim success As Boolean = False
        Dim rowsChanged As Integer
        Dim tab As New DataTable
        Try
            tab = LoadPayments()

            Dim row As DataRow = tab.NewRow()
            row(1) = amount
            row(2) = paymentDate
            row(3) = method
            row(4) = hireID
            tab.Rows.Add(row)

            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_EnterPayment"
            cmd.Parameters.AddWithValue("@amount", amount)
            cmd.Parameters.AddWithValue("@paymentDate", paymentDate)
            cmd.Parameters.AddWithValue("@method", method)
            cmd.Parameters.AddWithValue("@hireID", hireID)
            dataAdapter.InsertCommand = cmd
            builder = New SqlCommandBuilder(dataAdapter)
            rowsChanged = dataAdapter.Update(tab)
            If rowsChanged = 1 Then
                success = True
            Else
                success = False
            End If
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return success
    End Function

    ''' <summary>
    ''' Finds the payment with a matching hire ID
    ''' </summary>
    ''' <param name="id">
    ''' Hire ID of the payment.
    ''' </param>
    ''' <returns>
    ''' Payment with matching hire ID.
    ''' </returns>
    Public Shared Function getPaymentByHireID(id As Integer) As DataTable
        Dim dSet As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Dim comBuilder As New SqlCommandBuilder
        Dim col(0) As DataColumn
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.Parameters.AddWithValue("@hireID", id)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_getPaymentByHireId"
            dataAdapter.SelectCommand = cmd
            dataAdapter.Fill(dSet, "Payment")
            col(0) = dSet.Tables("Payment").Columns("Paymnet")
            dSet.Tables("Payment").PrimaryKey = col
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dSet.Tables("Payment")
    End Function

End Class
