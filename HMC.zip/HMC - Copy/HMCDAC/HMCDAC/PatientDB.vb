﻿'EquipmentDB
'Has methods for reading from and updating the Patient table.
'Mason Ward
'27/11/2019
Imports System.Data.SqlClient

Public Class PatientDB
    'Shared dataAdapter As SqlDataAdapter
    'Shared dataSet As New DataSet
    Shared connStr As String = My.Settings.HMCConnectionString
    Shared conn As New SqlConnection(connStr)
    Shared comBuilder As New SqlCommandBuilder
    Shared query As String
    Shared col(0) As DataColumn

    ''' <summary>
    ''' Returns a datatable with all patients in the Patient table.
    ''' </summary>
    ''' <returns>
    ''' Datatable with all patients.
    ''' </returns>
    Public Shared Function GetPatientList() As DataTable
        Dim dataset As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Try
            query = "SELECT * FROM Patient"
            dataAdapter = New SqlDataAdapter(query, connStr)
            comBuilder = New SqlCommandBuilder(dataAdapter)
            dataAdapter.Fill(dataset, "Patient")
            col(0) = dataset.Tables("Patient").Columns("PatientID")
            dataset.Tables("Patient").PrimaryKey = col
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dataset.Tables("Patient")
    End Function

    ''' <summary>
    ''' Returns the patient with the matching patient ID
    ''' </summary>
    ''' <param name="ID">
    ''' Patient ID to be searched for.
    ''' </param>
    ''' <returns>
    ''' Patient with the matching ID.
    ''' </returns>
    Public Shared Function GetByID(ID As Integer) As DataTable
        Dim dSet As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Try
            Dim cmd As New SqlCommand
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_PatientGetByID"
            cmd.Parameters.AddWithValue("@patient_id", ID)
            dataAdapter.SelectCommand = cmd
            dataAdapter.Fill(dSet, "Patient")
            col(0) = dSet.Tables("Patient").Columns("PatientID")
            dSet.Tables("Patient").PrimaryKey = col
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dSet.Tables("Patient")
    End Function

    ''' <summary>
    ''' Returns the patientId, first name and last name of a patient.
    ''' </summary>
    ''' <returns>
    ''' PatientId, first name and last name of a patient.
    ''' </returns>
    Public Shared Function GetNames() As DataTable
        Dim dSet As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Try
            query = "SELECT patientID, firstN, lastN FROM Patient"
            dataAdapter = New SqlDataAdapter(query, connStr)
            comBuilder = New SqlCommandBuilder(dataAdapter)
            dataAdapter.Fill(dSet, "Patient")
            col(0) = dSet.Tables("Patient").Columns("PatientID")
            dSet.Tables("Patient").PrimaryKey = col
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dSet.Tables("Patient")
    End Function

End Class
