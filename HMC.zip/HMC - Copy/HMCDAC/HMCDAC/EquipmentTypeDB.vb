﻿'EquipmentDB
'Has methods for reading from and updating the EquipmentType table.
'Mason Ward
'8/12/2019

Imports System.Data.SqlClient

Public Class EquipmentTypeDB
    Shared connStr As String = My.Settings.HMCConnectionString
    Shared conn As New SqlConnection(connStr)

    ''' <summary>
    ''' Returns a datatable with all equipment types.
    ''' </summary>
    ''' <returns></returns>
    Public Shared Function GetTypeList() As DataTable
        Dim dataset As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Dim query As String
        Dim comBuilder As SqlCommandBuilder
        Try
            query = "SELECT * FROM EquipmentType"
            dataAdapter = New SqlDataAdapter(query, connStr)
            comBuilder = New SqlCommandBuilder(dataAdapter)
            dataAdapter.Fill(dataset, "EquipmentType")
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dataset.Tables("EquipmentType")
    End Function

    ''' <summary>
    ''' Searches for an equipment type with a matching ID and returns it in a datatable.
    ''' </summary>
    ''' <param name="ID">
    ''' Equipment type ID.
    ''' </param>
    ''' <returns>
    ''' Datatable with the matching equipment type.
    ''' </returns>
    Public Shared Function GetByTypeID(ID As String) As DataTable
        Dim dSet As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Try
            Dim cmd As New SqlCommand
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_EquipmentTypeGetByTypeID"
            cmd.Parameters.AddWithValue("@typeID", ID)
            dataAdapter.SelectCommand = cmd
            dataAdapter.Fill(dSet, "EquipmentType")
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dSet.Tables("EquipmentType")
    End Function

    ''' <summary>
    ''' Returns the cost per day of an equipment type.
    ''' </summary>
    ''' <param name="ID">
    ''' Equipment type ID
    ''' </param>
    ''' <returns>
    ''' Cost per day of the equipment type as a decimal.
    ''' </returns>
    Public Shared Function GetByCostPerDay(ID As String) As Decimal
        Dim dSet As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Dim costPerDay As Decimal = 0
        Dim row As DataRow
        Dim table As DataTable
        Try
            Dim cmd As New SqlCommand
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_EquipTypeGetCostPerDay"
            cmd.Parameters.AddWithValue("@typeID", ID)
            dataAdapter.SelectCommand = cmd
            dataAdapter.Fill(dSet, "EquipmentType")
            table = dSet.Tables("EquipmentType")
            row = table.Rows(0)
            costPerDay = Convert.ToDecimal(row(0).ToString)
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return costPerDay
    End Function

    ''' <summary>
    ''' Reads from NewEquipment.xml and inserts any new equipment to the Equipment table in the database.
    ''' </summary>
    ''' <returns>
    ''' True if successful, false if not.
    ''' </returns>
    Public Shared Function UpdateFromXML() As Boolean
        Dim newTable As DataTable
        Dim oldTable As DataTable
        Dim found As Boolean = False
        Dim success As Boolean = False
        Try
            newTable = XMLUtils.ReadEquipType
            oldTable = GetTypeList()
            For Each r1 As DataRow In newTable.Rows
                For Each r2 As DataRow In oldTable.Rows
                    If Trim(r1(0).ToString) = Trim(r2(0).ToString) Then
                        found = True
                    End If
                Next
                If found = False Then
                    success = EnterType(r1)
                End If
            Next
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' Inserts a new equipment type into the EquipmentType table.
    ''' </summary>
    ''' <param name="row">
    ''' Row with the new equipment type.
    ''' </param>
    ''' <returns></returns>
    Public Shared Function EnterType(row As DataRow) As Boolean
        Dim dSet As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Dim typeID As String
        Dim description As String
        Dim checkPeriod As Integer
        Dim costPerDay As Decimal
        Dim tab As DataTable
        Dim rowsChanged As Integer
        Dim success As Boolean
        Dim newRow As DataRow
        typeID = row(0).ToString
        description = row(1).ToString
        checkPeriod = CInt(row(2))
        costPerDay = Convert.ToDecimal(row(3))
        Try
            tab = GetTypeList()
            newRow = tab.NewRow
            newRow(0) = typeID
            newRow(1) = description
            newRow(2) = checkPeriod
            newRow(3) = costPerDay
            tab.Rows.Add(newRow)
            Dim cmd As New SqlCommand
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_EnterType"
            cmd.Parameters.AddWithValue("@typeID", typeID)
            cmd.Parameters.AddWithValue("@description", description)
            cmd.Parameters.AddWithValue("@checkPeriod", checkPeriod)
            cmd.Parameters.AddWithValue("@costPerDay", costPerDay)
            dataAdapter.InsertCommand = cmd
            rowsChanged = dataAdapter.Update(tab)
            If rowsChanged = 1 Then
                success = True
            Else
                success = False
            End If
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return success
    End Function

End Class
