﻿'EquipmentDB
'Has methods for reading from and updating the Equipment table.
'Mason Ward
'8/12/2019

Imports System.Data.SqlClient

Public Class EquipmentDB
    Shared connStr As String = My.Settings.HMCConnectionString
    Shared conn As New SqlConnection(connStr)

    Public Shared Function GetEquipmentList() As DataTable
        Dim dataset As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Dim query As String
        Dim comBuilder As SqlCommandBuilder
        Try
            query = "SELECT * FROM Equipment"
            dataAdapter = New SqlDataAdapter(query, connStr)
            comBuilder = New SqlCommandBuilder(dataAdapter)
            dataAdapter.Fill(dataset, "Equipment")
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dataset.Tables("Equipment")
    End Function

    ''' <summary>
    ''' Finds an equipment by searching for its serial number and returns a datatable with that equipment.
    ''' </summary>
    ''' <param name="serialNo">
    ''' Serial number of the equipment.
    ''' </param>
    ''' <returns>
    ''' Datatable with the matching equipment.
    ''' </returns>
    Public Shared Function GetBySerialNo(serialNo As String) As DataTable
        Dim dSet As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Try
            Dim cmd As New SqlCommand
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_EquipmentGetBySerialNo"
            cmd.Parameters.AddWithValue("@serialNo", serialNo)
            dataAdapter.SelectCommand = cmd
            dataAdapter.Fill(dSet, "Equipment")
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dSet.Tables("Equipment")
    End Function

    ''' <summary>
    ''' Reads from NewEquipment.xml and inserts any new equipment to the Equipment table in the database.
    ''' </summary>
    ''' <returns>
    ''' True if successful, false if not.
    ''' </returns>
    Public Shared Function UpdateFromXML() As Boolean
        Dim newTable As DataTable
        Dim oldTable As DataTable
        Dim found As Boolean = False
        Dim success As Boolean = False
        newTable = XMLUtils.ReadEquipment
        oldTable = GetEquipmentList()
        Try
            For Each r1 As DataRow In newTable.Rows
                For Each r2 As DataRow In oldTable.Rows
                    If Trim(r1(0).ToString) = Trim(r2(0).ToString) Then
                        found = True
                        Exit For
                    End If
                Next
                If found = False Then
                    success = EnterEquipment(r1)
                End If
            Next
        Catch ex As Exception
            Throw ex
        End Try

    End Function

    ''' <summary>
    ''' Inserts a new equipment into the Equipment table
    ''' </summary>
    ''' <param name="row">
    ''' Datarow of the equipment table before it was updated.
    ''' </param>
    ''' <returns>
    ''' True is successful, false if not.
    ''' </returns>
    Public Shared Function EnterEquipment(row As DataRow) As Boolean
        Dim dSet As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Dim serialNo As String
        Dim eType As String
        Dim purchased As Date
        Dim lastChecked As Date
        Dim equipCondition As String
        Dim countryMade As String
        Dim tab As DataTable
        Dim rowsChanged As Integer
        Dim success As Boolean
        Dim newRow As DataRow
        serialNo = row(0).ToString
        eType = row(1).ToString
        purchased = CDate(row(2).ToString)
        lastChecked = CDate(row(3).ToString)
        equipCondition = row(4).ToString
        countryMade = row(5).ToString
        Try
            tab = GetEquipmentList()
            newRow = tab.NewRow
            newRow(0) = serialNo
            newRow(1) = eType
            newRow(2) = purchased
            newRow(3) = lastChecked
            newRow(4) = equipCondition
            newRow(5) = countryMade
            tab.Rows.Add(newRow)
            Dim cmd As New SqlCommand
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_EnterEquipment"
            cmd.Parameters.AddWithValue("@serialNo", serialNo)
            cmd.Parameters.AddWithValue("@eType", eType)
            cmd.Parameters.AddWithValue("@purchased", purchased)
            cmd.Parameters.AddWithValue("@lastChecked", lastChecked)
            cmd.Parameters.AddWithValue("@equipCondition", equipCondition)
            cmd.Parameters.AddWithValue("@countryMade", countryMade)
            dataAdapter.InsertCommand = cmd
            rowsChanged = dataAdapter.Update(tab)
            If rowsChanged = 1 Then
                success = True
            Else
                success = False
            End If
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return success
    End Function

    ''' <summary>
    ''' Finds all equipment of an equipment type and returns them in a datatable.
    ''' </summary>
    ''' <param name="eType">
    ''' Equipment type code.
    ''' </param>
    ''' <returns>
    ''' Datatable of equipment.
    ''' </returns>
    Public Shared Function GetByType(eType As String) As DataTable
        Dim dSet As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Dim query As String
        Dim comBuilder As SqlCommandBuilder
        Try
            Dim cmd As New SqlCommand
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_EquipmentGetByeType"
            cmd.Parameters.AddWithValue("@eType", eType)
            dataAdapter.SelectCommand = cmd
            dataAdapter.Fill(dSet, "Equipment")
        Catch ex As SqlException
            MessageBox.Show("Error")
        Catch ex As Exception
            Throw ex
        End Try
        Return dSet.Tables("Equipment")
    End Function
End Class
