﻿'EquipmentDB
'Has methods for reading from and updating the Hire table.
'Mason Ward
'8/12/2019

Imports System.Data.SqlClient
Public Class HireDB

    Shared connStr As String = My.Settings.HMCConnectionString
    Shared conn As New SqlConnection(connStr)

    ''' <summary>
    ''' Returns all of the hires from the Hire table in a dataset.
    ''' </summary>
    ''' <returns>
    ''' Dataset with all of the hires.
    ''' </returns>
    Public Shared Function LoadHires() As DataSet
        Dim dataAdapter As SqlDataAdapter
        Dim dataSet As New DataSet
        Dim comBuilder As New SqlCommandBuilder
        Dim query As String = "SELECT * FROM Hire"
        Dim col(0) As DataColumn
        Try
            dataAdapter = New SqlDataAdapter(query, connStr)
            comBuilder = New SqlCommandBuilder(dataAdapter)
            dataAdapter.Fill(dataSet, "Hire")
            col(0) = dataSet.Tables("Hire").Columns("PatientID")
            dataSet.Tables("Hire").PrimaryKey = col
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dataSet
    End Function

    ''' <summary>
    ''' Searches for a hire with the matching hire ID and returns it in a datatable.
    ''' </summary>
    ''' <param name="id">
    ''' Hire ID.
    ''' </param>
    ''' <returns>
    ''' A datatable with the matching hire.
    ''' </returns>
    Public Shared Function GetByHireID(id As Integer) As DataTable
        Dim dSet As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Dim comBuilder As New SqlCommandBuilder
        Dim col(0) As DataColumn
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.Parameters.AddWithValue("@hireID", id)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_HireGetByID"
            dataAdapter.SelectCommand = cmd
            dataAdapter.Fill(dSet, "Hire")
            col(0) = dSet.Tables("Hire").Columns("Hire")
            dSet.Tables("Hire").PrimaryKey = col
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dSet.Tables("Hire")
    End Function

    ''' <summary>
    ''' Searches for a hire with matching patient ID and returns it in a datatable.
    ''' </summary>
    ''' <param name="ID">
    ''' Patient ID of the hire.
    ''' </param>
    ''' <returns>
    ''' Datatable with the matching hire.
    ''' </returns>
    Public Shared Function GetByPatID(ID As Integer) As DataTable
        Dim dSet As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Dim comBuilder As New SqlCommandBuilder
        Dim col(0) As DataColumn
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.Parameters.AddWithValue("@patID", ID)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_HireGetByPatID"
            dataAdapter.SelectCommand = cmd
            dataAdapter.Fill(dSet, "Hire")
            col(0) = dSet.Tables("Hire").Columns("Hire")
            dSet.Tables("Hire").PrimaryKey = col
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dSet.Tables("Hire")
    End Function

    ''' <summary>
    ''' Inserts a new hire in to the Hire table.
    ''' </summary>
    ''' <param name="patID"></param>
    ''' Patient ID
    ''' <param name="serialNo"></param>
    ''' Serial number.
    ''' <param name="dateHired"></param>
    ''' Date the hire was made.
    ''' <param name="dateReturned"></param>
    ''' Date the hire was returned.
    ''' <param name="hirecost">
    ''' Full cost of the hire.
    ''' </param>
    ''' <returns>
    ''' True if successful, false if not.
    ''' </returns>
    Public Shared Function EnterHire(patID As Integer, serialNo As String, dateHired As Date, dateReturned As Date, hirecost As Decimal) As Boolean
        Dim dataAdapter As New SqlDataAdapter
        Dim builder As SqlCommandBuilder
        Dim cmd As New SqlCommand
        Dim success As Boolean = False
        Dim rowsChanged As Integer
        Dim dt As New DataSet
        Dim tab As New DataTable
        Try
            dt = LoadHires()
            tab = dt.Tables("Hire")

            Dim row As DataRow = tab.NewRow()
            row(1) = patID
            row(2) = serialNo
            row(3) = dateHired
            row(4) = dateReturned
            row(5) = hirecost
            tab.Rows.Add(row)

            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_EnterHire"
            cmd.Parameters.AddWithValue("@patID", patID)
            cmd.Parameters.AddWithValue("@serialNo", serialNo)
            cmd.Parameters.AddWithValue("@dateHired", dateHired)
            If dateReturned.Year = 1 Then
                cmd.Parameters.AddWithValue("@dateReturned", DBNull.Value)
            Else
                cmd.Parameters.AddWithValue("@dateReturned", dateReturned)
            End If
            If hirecost = 0 Then
                cmd.Parameters.AddWithValue("@hireCost", DBNull.Value)
            Else
                cmd.Parameters.AddWithValue("@hireCost", hirecost)
            End If

            dataAdapter.InsertCommand = cmd
            builder = New SqlCommandBuilder(dataAdapter)
            rowsChanged = dataAdapter.Update(tab)
            If rowsChanged = 1 Then
                success = True
            Else
                success = False
            End If
        Catch ex As SqlException
            Throw ex
            success = False
        Catch ex As Exception
            Throw ex
        End Try
        Return success
    End Function

    ''' <summary>
    ''' Sets the return date and hireCost of the hire in the database.
    ''' </summary>
    ''' <param name="ID">
    ''' Hire ID
    ''' </param>
    ''' <param name="cost">
    ''' Hire cost
    ''' </param>
    ''' <returns>
    ''' True if successful, false if not.
    ''' </returns>
    Public Shared Function ReturnHire(ID As Integer, cost As Decimal) As Boolean
        Dim query As String
        Dim dataAdapter As New SqlDataAdapter
        Dim builder As SqlCommandBuilder
        Dim dSet As New DataSet
        Dim cmd As New SqlCommand
        Dim today As Date = DateTime.Now
        Dim rowsChanged As Integer
        Dim success As Boolean = False
        Dim tab As DataTable
        Try
            dSet = LoadHires()
            tab = dSet.Tables("Hire")
            For Each r As DataRow In tab.Rows
                If r(0).ToString = CStr(ID) Then
                    r(5) = cost
                    r(4) = today
                End If
            Next
            cmd.Connection = conn
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_ReturnHire"
            cmd.Parameters.AddWithValue("@date", today)
            cmd.Parameters.AddWithValue("@cost", cost)
            cmd.Parameters.AddWithValue("@hireID", ID)
            dataAdapter.UpdateCommand = cmd
            builder = New SqlCommandBuilder(dataAdapter)
            rowsChanged = dataAdapter.Update(tab)
            If rowsChanged = 1 Then
                success = True
            Else
                success = False
            End If
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return success
    End Function

    ''' <summary>
    ''' Finds a hire with the matching equipment serial number.
    ''' </summary>
    ''' <param name="serialNo">
    ''' Serial number of the equipment.
    ''' </param>
    ''' <returns>
    ''' Datatable with the matching hire.
    ''' </returns>
    Public Shared Function getBySerialNo(serialNo As String) As DataTable
        Dim dSet As New DataSet
        Dim dataAdapter As New SqlDataAdapter
        Dim comBuilder As New SqlCommandBuilder
        Dim col(0) As DataColumn
        Dim cmd As New SqlCommand
        Try
            cmd.Connection = conn
            cmd.Parameters.AddWithValue("@serialNo", serialNo)
            cmd.CommandType = CommandType.StoredProcedure
            cmd.CommandText = "usp_HireGetSerialNo"
            dataAdapter.SelectCommand = cmd
            dataAdapter.Fill(dSet, "Hire")
            col(0) = dSet.Tables("Hire").Columns("Hire")
            dSet.Tables("Hire").PrimaryKey = col
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dSet.Tables("Hire")
    End Function

End Class
