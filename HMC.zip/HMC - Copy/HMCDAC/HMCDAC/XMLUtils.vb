﻿'EquipmentDB
'Has methods for reading from xml files.
'Mason Ward
'27/11/2019

Imports System.Xml
Imports System.Data

Public Class XMLUtils
    Shared dir As String = Application.StartupPath
    Shared EquipTypesPath As String = dir & "\data\NewEquipTypes.xml"
    Shared EquipmentPath As String = dir & "\data\NewEquipment.xml"
    Shared settings As New XmlReaderSettings
    Shared EquipTypeIn As XmlReader = XmlReader.Create(EquipTypesPath, settings)
    Shared EquipmentIn As XmlReader = XmlReader.Create(EquipmentPath, settings)

    ''' <summary>
    ''' Reads from the equipment type xml file
    ''' </summary>
    ''' <returns>
    ''' Datatable with all equipment types in the xml file.
    ''' </returns>
    Public Shared Function ReadEquipType() As DataTable
        Dim data As New DataSet
        data.ReadXml(EquipTypeIn)
        Return data.Tables(0)
    End Function

    ''' <summary>
    ''' Reads from the equipment xml file.
    ''' </summary>
    ''' <returns>
    ''' Datatable with all equipment in the xml file.
    ''' </returns>
    Public Shared Function ReadEquipment() As DataTable
        Dim data As New DataSet
        data.ReadXml(EquipmentIn)
        Return data.Tables(0)
    End Function

End Class
