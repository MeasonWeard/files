﻿Imports HMCGUI.FormMain

Public Class Start
    Private Sub Start_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim gui As New HMCGUI.FormMain
        gui.Show()
    End Sub
End Class