﻿'Equipment
'Mason Ward
'8/12/2019

Imports HMCDAC
Imports System.Data.SqlClient
Public Class Equipment
    Dim _serialNo As String
    Dim _eType As EquipmentType
    Dim _purchased As Date
    Dim _lastChecked As Date
    Dim _equipCondition As String
    Dim _countryMade As String
    Shared _nextSerialNo As String = "0"

    Public Shared ReadOnly Property NextSerialNo As String
        Get
            Return _nextSerialNo
        End Get
    End Property

    Public Property SerialNo As String
        Get
            Return _serialNo
        End Get
        Set(value As String)
            _serialNo = value
        End Set
    End Property

    Public Property eType As EquipmentType
        Get
            Return _eType
        End Get
        Set(value As EquipmentType)
            _eType = value
        End Set
    End Property

    Public Property Purchased As Date
        Get
            Return _purchased
        End Get
        Set(value As Date)
            _purchased = value
        End Set
    End Property

    Public Property LastChecked As Date
        Get
            Return _lastChecked
        End Get
        Set(value As Date)
            _lastChecked = value
        End Set
    End Property

    Public Property EquipCondition As String
        Get
            Return _equipCondition
        End Get
        Set(value As String)
            _equipCondition = value
        End Set
    End Property

    Public Property CountryMade As String
        Get
            Return _countryMade
        End Get
        Set(value As String)
            _countryMade = value
        End Set
    End Property

    Public Sub New(newSerialNo As String, newEType As EquipmentType, newPurchased As Date, newLastChecked As Date, newEquipCondition As String, newCountryMade As String)
        SerialNo = newSerialNo
        eType = newEType
        Purchased = newPurchased
        LastChecked = newLastChecked
        EquipCondition = newEquipCondition
        CountryMade = newCountryMade
    End Sub

    ''' <summary>
    ''' Reads from NewEquipment.xml and inserts any new equipment to the Equipment table in the database.
    ''' </summary>
    ''' <returns>
    ''' True if successful, false if not.
    ''' </returns>
    Public Shared Function Update() As Boolean
        Dim success As Boolean = False
        Try
            success = EquipmentDB.UpdateFromXML
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
    End Function

    ''' <summary>
    ''' Loads Equipment table to a datatable
    ''' </summary>
    ''' <returns>
    ''' Datatable of equipment
    ''' </returns>
    Public Shared Function LoadEquipment() As DataTable
        Dim dt As New DataTable
        Try
            dt = EquipmentDB.GetEquipmentList()
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dt
    End Function

    ''' <summary>
    ''' Returns a datatable with the equipment of matching serialNo
    ''' </summary>
    ''' <param name="serialNo">
    ''' Serial code to be searched for
    ''' </param>
    ''' <returns>
    ''' Datatable with matching equipment
    ''' </returns>
    Public Shared Function GetByType(serialNo As String) As DataTable
        Dim dt As New DataTable
        Try
            dt = EquipmentDB.GetByType(serialNo)
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dt
    End Function

    ''' <summary>
    ''' Checks to see whether or not an equipment is currently on hire.
    ''' </summary>
    ''' <param name="serialNo">
    ''' serialNo to be searched for.
    ''' </param>
    ''' <returns>
    ''' True if the equipment is available, false if it isn't.
    ''' </returns>
    Public Shared Function IsAvailable(serialNo As String) As Boolean
        Dim dt As New DataTable
        Dim available As Boolean
        Dim rDate As New Date
        Dim today As New Date
        today = Date.Today
        Try
            dt = HireDB.getBySerialNo(serialNo)
            available = True
            If dt.Rows.Count > 0 Then
                For Each hire As DataRow In dt.Rows
                    If hire("dateReturned").ToString = "" Then
                        available = False
                    Else
                        rDate = Convert.ToDateTime(hire("dateReturned").ToString)
                        If Date.Compare(today, rDate) = 1 Or Date.Compare(today, rDate) = 0 Then
                            'available = True
                        Else
                            available = False
                        End If
                    End If
                Next
            End If
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return available
    End Function

End Class
