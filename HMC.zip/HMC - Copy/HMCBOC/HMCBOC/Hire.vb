﻿'Hire
'Mason Ward
'8/12/2019

Imports HMCDAC
Imports System.Data.SqlClient
Public Class Hire
    Dim _hireID As Integer
    Dim _patientID As Integer
    Dim _serialNo As String
    Dim _dateHired As Date
    Dim _dateReturned As Date
    Dim _hireCost As Decimal
    Dim _current As Boolean
    Shared _nextID As Integer = 0

    Public ReadOnly Property HireID As Integer
        Get
            Return _hireID
        End Get
    End Property

    Public ReadOnly Property PatientID As Integer
        Get
            Return _patientID
        End Get
    End Property

    Public ReadOnly Property SerialNo As String
        Get
            Return _serialNo
        End Get
    End Property

    Public Property DateHired As Date
        Get
            Return _dateHired
        End Get
        Set(value As Date)
            _dateHired = value
        End Set
    End Property

    Public Property DateReturned As Date
        Get
            Return _dateReturned
        End Get
        Set(value As Date)
            _dateReturned = value
        End Set
    End Property

    Public Property HireCost As Decimal
        Get
            Return _hireCost
        End Get
        Set(value As Decimal)
            _hireCost = value
        End Set
    End Property

    Public Property Current As Boolean
        Get
            Return _current
        End Get
        Set(value As Boolean)
            _current = value
        End Set
    End Property

    Public Sub New(newPatienID As Integer, newSerialNo As String, newDateHired As Date, newDateReturned As Date,
                   newHireCost As Decimal)
        _patientID = newPatienID
        _serialNo = newSerialNo
        DateHired = newDateHired
        DateReturned = newDateReturned
        HireCost = newHireCost
    End Sub

    Public Sub New(newHireID As Integer, newPatienID As Integer, newSerialNo As String, newDateHired As Date, newDateReturned As Date,
                   newHireCost As Decimal)
        _hireID = newHireID
        _patientID = newPatienID
        _serialNo = newSerialNo
        DateHired = newDateHired
        DateReturned = newDateReturned
        HireCost = newHireCost
    End Sub

    ''' <summary>
    ''' Loads Hire table to a datatable
    ''' </summary>
    ''' <returns>
    ''' Datatable of Hires
    ''' </returns>
    Public Shared Function LoadHires() As DataSet
        Dim dataTable As DataSet
        Try
            dataTable = HMCDAC.HireDB.LoadHires()
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dataTable
    End Function

    ''' <summary>
    ''' Returns a List of Hires which match a patientID
    ''' </summary>
    ''' <param name="ID">
    ''' Patient's ID number
    ''' </param>
    ''' <returns>
    ''' List (Of Hire)
    ''' </returns>
    Public Shared Function GetByPatID(ID As Integer) As List(Of Hire)
        Dim dataTable As New DataTable
        Dim hireList As New List(Of Hire)
        Dim newID As Integer
        Dim patID As Integer
        Dim serialNo As String
        Dim dateHiredStr As String
        Dim dateReturnedStr As String
        Dim dateHired As Date
        Dim dateReturned As Date
        Dim hireCost As Decimal
        Try
            dataTable = HireDB.GetByPatID(ID)
            For Each row As DataRow In dataTable.Rows
                newID = CInt(row(0).ToString)
                patID = CInt(row(1).ToString)
                serialNo = row(2).ToString
                dateHiredStr = row(3).ToString
                dateReturnedStr = row(4).ToString
                dateHired = Convert.ToDateTime(dateHiredStr)
                If dateReturnedStr <> "" Then
                    dateReturned = Convert.ToDateTime(dateReturnedStr)
                Else
                    dateReturned = Nothing
                End If
                If row(5).ToString <> "" Then
                    hireCost = CDec(row(5).ToString)
                Else
                    hireCost = 0.0D
                End If
                Dim hire As New Hire(newID, patID, serialNo, dateHired, dateReturned, hireCost)
                hireList.Add(hire)
            Next
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return hireList
    End Function

    ''' <summary>
    ''' Calculates hireCost then updates the hireCost and dateReturned to the current date in the Hire table of the database.
    ''' </summary>
    ''' <param name="ID">
    ''' The hire's hireID
    ''' </param>
    ''' <returns>
    ''' True if successfully updated, false if not.
    ''' </returns>
    Public Shared Function ReturnHire(ID As Integer) As Boolean
        Dim success As Boolean
        Dim cost As Decimal
        Dim hireDate As Date
        Dim days As Integer
        Dim span As TimeSpan
        Dim equipmentID As String
        Dim equipTypeID As String
        Dim eTable As DataTable
        Dim row As DataRow
        Dim costPerDay As Decimal
        Dim dt As New DataTable
        Try
            dt = HireDB.GetByHireID(ID)
            row = dt.Rows(0)
            'calculate cost
            hireDate = Convert.ToDateTime(row(3).ToString)
            span = Today - hireDate
            days = CInt(span.TotalDays)
            equipmentID = row(2).ToString
            eTable = EquipmentDB.GetBySerialNo(equipmentID)
            row = eTable.Rows(0)
            equipTypeID = row(1).ToString
            costPerDay = EquipmentTypeDB.GetByCostPerDay(equipTypeID)
            cost = costPerDay * days
            success = HireDB.ReturnHire(ID, cost)
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return success
    End Function

    ''' <summary>
    ''' Inserts a new hire into the Hire table of the database.
    ''' </summary>
    ''' <param name="hire">
    ''' Hire object
    ''' </param>
    ''' <returns>
    ''' True if successfully inserted, false if not.
    ''' </returns>
    Public Shared Function EnterHire(hire As Hire) As Boolean
        Dim success As Boolean
        Try
            success = HireDB.EnterHire(hire.PatientID, hire.SerialNo, hire.DateHired, hire.DateReturned, hire.HireCost)
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return success
    End Function

    ''' <summary>
    ''' Determines whether or not a hire has a matching payment.
    ''' </summary>
    ''' <param name="id">
    ''' hireID of the hire.
    ''' </param>
    ''' <returns>
    ''' True of there is a matching payment, false if not.
    ''' </returns>
    Public Shared Function hasBeenPaid(id As Integer) As Boolean
        Dim yes As Boolean
        Dim dt As DataTable
        Try
            dt = PaymentDB.getPaymentByHireID(id)
            If dt.Rows.Count > 0 Then
                yes = True
            Else
                yes = False
            End If
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return yes
    End Function


End Class
