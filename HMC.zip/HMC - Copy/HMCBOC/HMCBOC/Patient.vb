﻿'Patient
'Mason Ward
'8/12/2019

Imports HMCDAC
Imports System.Data.SqlClient
Public Class Patient
    Dim _patientID As Integer
    Dim _title As String
    Dim _firstName As String
    Dim _lastName As String
    Dim _street As String
    Dim _suburb As String
    Dim _state As String
    Dim _postCode As String
    Dim _phone As String
    Dim _email As String
    Shared _nextID As Integer = 0

    Public Property PatientID As Integer
        Get
            Return _patientID
        End Get
        Set(value As Integer)
            _patientID = value
        End Set
    End Property

    Public Property Title As String
        Get
            Return _title
        End Get
        Set(value As String)
            _title = value
        End Set
    End Property

    Public Property FirstName As String
        Get
            Return _firstName
        End Get
        Set(value As String)
            _firstName = value
        End Set
    End Property

    Public Property LastName As String
        Get
            Return _lastName
        End Get
        Set(value As String)
            _lastName = value
        End Set
    End Property

    Public Property Street As String
        Get
            Return _street
        End Get
        Set(value As String)
            _street = value
        End Set
    End Property

    Public Property Suburb As String
        Get
            Return _suburb
        End Get
        Set(value As String)
            _suburb = value
        End Set
    End Property

    Public Property State As String
        Get
            Return _state
        End Get
        Set(value As String)
            _state = value
        End Set
    End Property

    Public Property PostCode As String
        Get
            Return _postCode
        End Get
        Set(value As String)
            _postCode = value
        End Set
    End Property

    Public Property Phone As String
        Get
            Return _phone
        End Get
        Set(value As String)
            _phone = value
        End Set
    End Property

    Public Property Email As String
        Get
            Return _email
        End Get
        Set(value As String)
            _email = value
        End Set
    End Property

    Public ReadOnly Property NextID As Integer
        Get
            Return _nextID
        End Get
    End Property

    Public Sub New()

    End Sub

    Public Sub New(newPatientID As Integer, newTitle As String, newFirstName As String, newLastName As String, newStreet As String,
                   newSuburb As String, newState As String, newPostCode As String, newPhone As String, newEmail As String)
        PatientID = _nextID
        _nextID += 1
        Title = newTitle
        FirstName = newFirstName
        LastName = newLastName
        Street = newStreet
        Suburb = newSuburb
        State = newState
        PostCode = newPostCode
        Phone = newPhone
        Email = newEmail
    End Sub

    ''' <summary>
    ''' Loads Patient table to a datatable
    ''' </summary>
    ''' <returns>
    ''' Datatable of patients
    ''' </returns>
    Public Shared Function LoadPatients() As DataTable
        Dim dataTable As DataTable
        Try
            dataTable = PatientDB.GetPatientList
        Catch ex As SqlException
            Throw ex
        Catch ex As exception
            Throw ex
        End Try
        Return dataTable
    End Function


    'Public Shared Function GetPatientList() As List(Of String)
    '    Dim dataTable As DataTable
    '    Dim patientList As New List(Of String)
    '    Dim id As String
    '    Dim title As String
    '    Dim firstName As String
    '    Dim lastName As String
    '    dataTable = PatientDB.GetPatientList
    '    Try
    '        For Each r As DataRow In dataTable.Rows
    '            id = r(0).ToString
    '            title = r(1).ToString
    '            firstName = r(2).ToString
    '            lastName = r(3).ToString
    '            patientList.Add(id & " - " & title & " " & firstName & " " & lastName)
    '        Next
    '    Catch ex As SqlException
    '        Throw ex
    '    Catch ex As exception
    '        Throw ex
    '    End Try
    '    Return patientList
    'End Function

    ''' <summary>
    ''' Returns a List with all of a patients details as Strings
    ''' </summary>
    ''' <param name="ID">patiendID of the patient</param>
    ''' <param name="table">Datatable loaded from the Patient table in the database</param>
    ''' <returns>
    ''' patientID, title, firstN, lastN, street, suburb, state, pc, phone and email - all as strings
    ''' </returns>
    Public Shared Function GetPatientDetails(ID As Integer, table As DataTable) As List(Of String)
        Dim details As New List(Of String)
        Dim IDstr As String = CStr(ID)
        Dim found As Boolean = False
        For Each r As DataRow In table.Rows
            If r(0).ToString = IDstr Then
                found = True
                For Each i As Object In r.ItemArray
                    details.Add(i.ToString)
                Next
            End If
        Next
        Return details
    End Function

    ''' <summary>
    ''' Finds a patient in the Patient table and returns a patient object.
    ''' </summary>
    ''' <param name="ID">patientID of the patient.</param>
    ''' <returns>
    ''' Patient object.
    ''' </returns>
    Public Shared Function GetByID(ID As Integer) As Patient
        Dim dataTable As New DataTable
        Dim row As DataRow
        Dim newID As Integer
        Dim title As String
        Dim firstN As String
        Dim lastN As String
        Dim street As String
        Dim suburb As String
        Dim state As String
        Dim pc As String
        Dim phone As String
        Dim email As String
        Dim pat As New Patient(newID, title, firstN, lastN, street, suburb, state, pc, phone, email)
        Try
            dataTable = HMCDAC.PatientDB.GetByID(ID)
            If dataTable.Rows.Count = 1 Then
                row = dataTable.Rows(0)
                newID = CInt(row(0).ToString)
                title = row(1).ToString
                firstN = row(2).ToString
                lastN = row(3).ToString
                street = row(4).ToString
                suburb = row(5).ToString
                state = row(6).ToString
                pc = row(7).ToString
                phone = row(8).ToString
                email = row(9).ToString
                pat = New Patient(newID, title, firstN, lastN, street, suburb, state, pc, phone, email)
                Return pat
            Else
                Return Nothing
            End If
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
    End Function

End Class
