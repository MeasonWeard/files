﻿'Payment
'Mason Ward
'8/12/2019

Imports HMCDAC
Imports System.Data.SqlClient
Public Class Payment
    Dim _paymentID As Integer
    Dim _amount As Decimal
    Dim _method As String
    Dim _paymentDate As Date
    Dim _hireID As Integer
    Shared _nextID As Integer = 0

    Public ReadOnly Property PaymentID As Integer
        Get
            Return _paymentID
        End Get
    End Property

    Public Property Amount As Decimal
        Get
            Return _amount
        End Get
        Set(value As Decimal)
            _amount = value
        End Set
    End Property

    Public Property Method As String
        Get
            Return _method
        End Get
        Set(value As String)
            _method = value
        End Set
    End Property

    Public Property PaymentDate As Date
        Get
            Return _paymentDate
        End Get
        Set(value As Date)
            _paymentDate = value
        End Set
    End Property

    Public ReadOnly Property HireID As Integer
        Get
            Return _hireID
        End Get
    End Property

    Public Shared ReadOnly Property NextID As Integer
        Get
            Return _nextID
        End Get
    End Property

    Public Sub New(newAmount As Decimal, newPaymentDate As Date, newMethod As String, newHireID As Integer)
        _paymentID = NextID
        _nextID += 1
        Amount = newAmount
        Method = newMethod
        PaymentDate = newPaymentDate
        _hireID = newHireID
    End Sub

    ''' <summary>
    ''' Loads all payments from the Payment talbe in the database.
    ''' </summary>
    ''' <returns>
    ''' Datatable
    ''' </returns>
    Public Shared Function LoadPayments() As DataTable
        Dim dataTable As DataTable
        Try
            dataTable = HMCDAC.PaymentDB.LoadPayments
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dataTable
    End Function

    ''' <summary>
    ''' Inserts a new payment to the Payment table in the database
    ''' </summary>
    ''' <param name="payment">Payment object
    ''' </param>
    ''' <returns>
    ''' True if successfully inserted, false if not.
    ''' </returns>
    Public Shared Function EnterPayment(payment As Payment) As Boolean
        Dim success As Boolean
        Try
            success = PaymentDB.EnterPayment(payment.Amount, payment.PaymentDate, payment.Method, payment.HireID)
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return success
    End Function

End Class
