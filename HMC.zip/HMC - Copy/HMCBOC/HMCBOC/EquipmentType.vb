﻿'EquipmentType
'Mason Ward
'8/12/2019

Imports HMCDAC
Imports System.Data.SqlClient
Public Class EquipmentType
    Dim _typeID As String
    Dim _description As String
    Dim _checkPeriod As Integer
    Dim _costPerDay As Decimal
    Dim _equipmentType As String
    Shared _nextID As String = "0"

    Public Shared ReadOnly Property NextID As String
        Get
            Return _nextID
        End Get
    End Property

    Public Property TypeID As String
        Get
            Return _typeID
        End Get
        Set(value As String)
            _typeID = value
        End Set
    End Property

    Public Property Description As String
        Get
            Return _description
        End Get
        Set(value As String)
            _description = value
        End Set
    End Property

    Public Property CheckPeriod As Integer
        Get
            Return _checkPeriod
        End Get
        Set(value As Integer)
            _checkPeriod = value
        End Set
    End Property

    Public Property CostPerDay As Decimal
        Get
            Return _costPerDay
        End Get
        Set(value As Decimal)
            _costPerDay = value
        End Set
    End Property

    Public Property EquipmentType As String
        Get
            Return _equipmentType
        End Get
        Set(value As String)
            _equipmentType = value
        End Set
    End Property

    Public Sub New(newTypeID As String, newEquipmentType As String, newDescription As String, newCheckPeriod As Integer, newCostPerDay As Decimal)
        TypeID = newTypeID
        EquipmentType = newEquipmentType
        Description = newDescription
        CheckPeriod = newCheckPeriod
        CostPerDay = newCostPerDay
    End Sub

    ''' <summary>
    ''' Loads all equipment types to a datatable
    ''' </summary>
    ''' <returns>
    ''' Datatable with all equipment types in the EquipmentType table
    ''' </returns>
    Public Shared Function LoadEquipTypes() As DataTable
        Dim dt As New DataTable
        Try
            dt = EquipmentTypeDB.GetTypeList()
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return dt
    End Function

    ''' <summary>
    ''' Returns a List of strings with all equipment typeIDs and their descriptions.
    ''' </summary>
    ''' <returns>
    ''' List (Of String)
    ''' </returns>
    Public Shared Function GetTypeList() As List(Of String)
        Dim dt As New DataTable
        Dim typeList As New List(Of String)
        Dim id As String
        Dim desc As String
        Try
            dt = LoadEquipTypes()
            For Each r As DataRow In dt.Rows
                id = r(0).ToString
                desc = r(1).ToString
                typeList.Add(id & " - " & desc)
            Next
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return typeList
    End Function

    ''' <summary>
    ''' Reads from NewEquipment.xml and inserts any new equipment to the Equipment table in the database.
    ''' </summary>
    ''' <returns>
    ''' True if successful, false if not.
    ''' </returns>
    Public Shared Function Update() As Boolean
        Dim success As Boolean = False
        Try
            success = EquipmentTypeDB.UpdateFromXML
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return success
    End Function

    ''' <summary>
    ''' Returns the cost per day of an equipment type.
    ''' </summary>
    ''' <param name="ID">
    ''' typeID of the equipment type to be searched for.
    ''' </param>
    ''' <returns>
    ''' Cost per day as a decimal.
    ''' </returns>
    Public Shared Function GetCostPerDay(ID As String) As Decimal
        Dim cost As Decimal
        Try
            cost = EquipmentTypeDB.GetByCostPerDay(ID)
        Catch ex As SqlException
            Throw ex
        Catch ex As Exception
            Throw ex
        End Try
        Return cost
    End Function

End Class
