
CREATE PROCEDURE usp_ReturnHire @date DATE, @cost DECIMAL, @hireID INTEGER
AS
UPDATE Hire
SET dateReturned = @date, hirecost = @cost
WHERE hireID = @hireID
GO

CREATE PROCEDURE usp_EnterPayment @amount DECIMAL, @paymentDate DATE, @method VARCHAR(15), @hireID as INTEGER
AS
INSERT INTO Payment(amount, paymentDate, method, hireID)
VALUES (@amount, @paymentDate, @method, @hireID)
GO

CREATE PROCEDURE usp_getPaymentByHireId @hireID INTEGER
AS
SELECT * FROM Payment
WHERE hireID = @hireID
GO

CREATE PROCEDURE usp_HireGetByID @hireID INTEGER
AS
SELECT * FROM Hire
WHERE hireID = @hireID
GO

CREATE PROCEDURE usp_HireGetByPatID @patID INTEGER
AS
SELECT * FROM Hire
WHERE patID = @patID
GO

CREATE PROCEDURE usp_HireGetSerialNo @serialNo CHAR(10)
AS
SELECT * FROM Hire
WHERE serialNo = @serialNo
GO

CREATE PROCEDURE usp_HireList
AS
SELECT * FROM Hire
GO

CREATE PROCEDURE usp_EquipmentGetBySerialNo @serialNo VARCHAR(10)
AS
SELECT * FROM Equipment
WHERE serialNo = @serialNo
GO

CREATE PROCEDURE usp_EquipmentTypeGetByTypeID @typeID CHAR(3)
AS
SELECT * FROM EquipmentType
WHERE typeID = @typeID
GO

CREATE PROCEDURE usp_EquipTypeGetCostPerDay @typeID CHAR(3)
AS
SELECT costPerDay FROM EquipmentType
WHERE typeID = @typeID
GO

CREATE PROCEDURE usp_EnterType @typeID CHAR(3), @description VARCHAR(50), @checkPeriod INT, @costPerDay DECIMAL(5,2)
AS
INSERT INTO EquipmentType(typeID, description, checkPeriod, costPerDay)
VALUES (@typeID, @description, @checkPeriod, @costPerDay)
GO

CREATE PROCEDURE usp_EnterEquipment @serialNo CHAR(10), @eType CHAR(3), @purchased DATE, @lastChecked DATE, @equipCondition VARCHAR(15), @countryMade VARCHAR(25)
AS
INSERT INTO Equipment(serialNo, eType, purchased, lastChecked, equipCondition, countryMade)
VALUES (@serialNo, @eType, @purchased, @lastChecked, @equipCondition, @countryMade)
GO

CREATE PROCEDURE usp_EquipmentGetByeType @eType CHAR(3)
AS
SELECT * FROM Equipment
WHERE eType = @eType
GO


CREATE PROCEDURE usp_EnterHire @patID INTEGER, @serialNo CHAR(10), @dateHired DATE, @dateReturned DATE, @hireCost DECIMAL(6,2)
AS
INSERT INTO Hire(patID, serialNo, dateHired, dateReturned, hirecost)
VALUES (@patID, @serialNo, @dateHired, @dateReturned, @hireCost)
GO

